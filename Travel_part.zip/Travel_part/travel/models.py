# -*- coding: utf-8 -*-
#分开 spot hotel resta
from __future__ import unicode_literals

from django.db import models

# 地区基本信息表
class Area(models.Model):
    # 1sheng 2shi 3xian 4zhen 5cun
    Type=models.IntegerField()
    aname=models.CharField(max_length=50)
    a_id=models.CharField(max_length=100)
    apinyin=models.CharField(max_length=50)
    alongitude=models.FloatField()
    alatitude=models.FloatField()
    ainfo=models.TextField()
    aparent=models.CharField(max_length=50)
    aimg=models.ImageField(upload_to="images/pic")
    all_youji=models.IntegerField()
    charm_rank=models.IntegerField()
    all_dianping=models.IntegerField()
    all_spot=models.IntegerField()
    all_food=models.IntegerField()
    all_hotel=models.IntegerField()
    all_restaurant=models.IntegerField()
    all_pic=models.IntegerField()
    all_question=models.IntegerField()
    arank=models.CharField(max_length=100)
    class Meta:
        ordering=['arank']
    def __unicode__(self):
        return self.aname
# class Total(models.Model):
#     area=models.OneToOneField(Area)
#     all_youji=models.IntegerField()
#     all_dianping=models.IntegerField()
#     all_spot=models.IntegerField()
#     all_food=models.IntegerField()
#     all_hotel=models.IntegerField()
#     all_restaurant=models.IntegerField()
#     all_pic=models.IntegerField()
#     all_question=models.IntegerField()

class Charm_value(models.Model):
    area=models.OneToOneField(Area)
    mark=models.CharField(max_length=30)
    renqi=models.CharField(max_length=30)
    fuwu=models.CharField(max_length=30)
    manyidu=models.CharField(max_length=30)
    def __unicode__(self):
        return self.area
# class Hot_search(models.Model):
#     area=models.ForeignKey(Area)
#     search_type=models.IntegerField()
#     search_content=models.CharField(max_length=50)
#     def __unicode__(self):
#         return self.search_type

# 1景区 2酒店 3餐厅 基本信息
class Food(models.Model):
    area=models.ForeignKey(Area)
    food=models.CharField(max_length=50)
    score=models.CharField(max_length=30)
    frank=models.IntegerField()
    desc=models.CharField(max_length=50)
    eat_where=models.CharField(max_length=50)
    def __unicode__(self):
        return self.food


class BaseInfo(models.Model):
    name=models.CharField(max_length=50)
    location=models.CharField(max_length=50)
    longitude=models.FloatField()
    latitude=models.FloatField()
    Type=models.IntegerField()
    info=models.TextField()
    all_dp=models.IntegerField()
    all_yj=models.IntegerField()
    renjun=models.CharField(max_length=50)
    img=models.ImageField(upload_to='images/pic')
    hot_degree=models.CharField(max_length=50)
    score=models.CharField(max_length=100)
    class Meta:
        abstract=True
class Category_spot(models.Model):
    category=models.CharField(max_length=50)
class Spot(BaseInfo):
    spot_area=models.ForeignKey(Area)
    category=models.ManyToManyField(Category_spot)
    def __unicode__(self):
        return self.name
class Category_shop(models.Model):
    category_shop=models.CharField(max_length=50)
class Shop(BaseInfo):
    shop_area=models.ForeignKey(Area)
    category_shop=models.ForeignKey(Category_shop)
    # 1hotel 2 restaurant
    shop_type=models.IntegerField()
    def __unicode__(self):
        return self.name
class Leisure(models.Model):
    area=models.ForeignKey(Area)
    L_name=models.CharField(max_length=50)
    L_hot_degree=models.CharField(max_length=50)
    # 1 yule   2 gouwu
    L_Type=models.IntegerField()


# # class S_H_R_baseinfo(models.Model):
# #     area=models.ForeignKey(Area)
# #     name=models.CharField(max_length=50)
# #     longitude=models.FloatField()
# #     latitude=models.FloatField()
# #     Type=models.IntegerField()
# #     img=models.ImageField(upload_to='images/pic')
# #     score=models.CharField(max_length=100)
# #     def __unicode__(self):
# #         return self.name
class Category_youji(models.Model):
    category_youji=models.CharField(max_length=50)
class Youji(models.Model):
    area=models.ManyToManyField(Area)
    spot=models.ManyToManyField(Spot)
    shop=models.ManyToManyField(Shop)
    author=models.CharField(max_length=50)
    title=models.CharField(max_length=50)
    desc=models.CharField(max_length=50)
    img=models.ImageField(upload_to='images/pic')
    content=models.TextField()
    pubtime=models.DateTimeField()
    travel_type=models.CharField(max_length=50)
    use_time=models.CharField(max_length=20)
    use_money=models.CharField(max_length=20)
    looker_counter=models.IntegerField()
    comment_counter=models.IntegerField()
    category_youji=models.ForeignKey(Category_youji)
    score=models.CharField(max_length=50)
    class Meta:
        ordering=['-score','-pubtime']
    def __unicode__(self):
        return self.title
class Youji_comment(models.Model):
    youji=models.ForeignKey(Youji)
    content=models.TextField()
    comment_time=models.DateTimeField()
    comment_author=models.CharField(max_length=50)
    def __unicode__(self):
        return self.youji
class Dianping(models.Model):
    area=models.ForeignKey(Area)
    s_h_r=models.ManyToManyField(S_H_R_baseinfo)
    spot=models.ManyToManyField(Spot)
    shop=models.ManyToManyField(Shop)
    author=models.CharField(max_length=50)
    content=models.TextField()
    time=models.DateTimeField()
    score=models.CharField(max_length=100)
    class Meta:
        ordering=['score','time']
    def __unicode__(self):
        return self.id
class Category_question(models.Model):
    category=models.CharField(max_length=30)
class Question(models.Model):
    area=models.ManyToManyField(Area)
    # s_h_r=models.ManyToManyField(S_H_R_baseinfo)
    spot=models.ManyToManyField(Spot)
    Shop=models.ManyToManyField(Shop)
    # restaurant=models.ManyToManyField(Restaurant)
    title=models.CharField(max_length=50)
    content=models.TextField()
    time=models.DateTimeField()
    # q_category=models.ForeignKey(Category_question)
    score=models.CharField(max_length=50)
    class Meta:
        ordering=['score','id']
    def __unicode__(self):
      return self.title
class Answer(models.Model):
    Q=models.ForeignKey(Question)
    answer=models.CharField(max_length=100)
    time=models.DateTimeField()
    author=models.CharField(max_length=30)
    score=models.CharField(max_length=30)
    class Meta:
        ordering=['score','id']
    def __unicode__(self):
        return self.id
