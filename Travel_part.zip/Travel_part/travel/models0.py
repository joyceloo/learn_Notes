# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models


# Area
class Area(models.Model):
    aname=models.CharField(max_length=30)
    acode=models.CharField(max_length=20)
    apinyin=models.CharField(max_length=30)
    alongitude=models.FloatField()
    alatitude=models.FloatField()
    ainfo=models.TextField()
    aparent=models.CharField(max_length=50)
    aimg=models.ImageField(upload_to="images/pic")
    all_youji=models.IntegerField()
    charm_rank=models.IntegerField()
    all_dianping=models.IntegerField()
    all_spot=models.IntegerField()
    all_food=models.IntegerField()
    all_hotel=models.IntegerField()
    all_restaurant=models.IntegerField()
    all_pic=models.IntegerField()
    all_question=models.IntegerField()
    arank=models.CharField(max_length=100)
    class Meta:
        ordering=['arank']
    def __unicode__(self):
        return self.aname
class Charm_value(models.Model):
    area=models.OneToOneField(Area)
    mark=models.CharField(max_length=30)
    renqi=models.CharField(max_length=30)
    fuwu=models.CharField(max_length=30)
    manyidu=models.CharField(max_length=30)
    def __unicode__(self):
        return self.area

class Hot_area(models.Model):
    area=models.ForeignKey(Area)
    name=models.CharField(max_length=50)
    code=models.CharField(max_length=20)
    info=models.CharField(max_length=50)
    all_spot=models.IntegerField()
    all_food=models.IntegerField()
    all_hotel=models.IntegerField()
    recommnend_mark=models.CharField(max_length=30)
    class Meta:
        ordering=['recommnend_mark']
    def __unicode__(self):
        return self.name
class Spot_type(models.Model):
    Type=models.CharField(max_length=30)
    def __unicode__(self):
        return self.Type
class Hot_spot(models.Model):
    area=models.ForeignKey(Area)
    sname=models.CharField(max_length=50)
    sindex=models.CharField(max_length=20)
    s_type=models.ManyToManyField(Spot_type)
    recommnend_mark=models.CharField(max_length=30)
    all_youji=models.IntegerField()
    all_dianping=models.IntegerField()
    def __unicode__(self):
        return self.sname
class Food_type(models.Model):
    Type=models.CharField(max_length=30)
    def __unicode__(self):
        return self.Type
class Hot_food(models.Model):
    area=models.FloatField(Area)
    average_money=models.CharField(max_length=20)
    fname=models.CharField(max_length=50)
    recommnend_mark=models.CharField(max_length=30)
    f_type=models.ManyToManyField(Food_type)
    rank=models.IntegerField()
    info=models.CharField(max_length=100)
    rec_1=models.CharField(max_length=30)
    rec_2=models.CharField(max_length=30)
    rec_3=models.CharField(max_length=30)
    def __unicode__(self):
        return self.fnamea
# hotel
class Hotel_type(models.Model):
    Type=models.CharField(max_length=30)
    def __unicode__(self):
        return self.Type
class Hot_hotel(models.Model):
    area=models.ForeignKey(Area)
    hname=models.CharField(max_length=30)
    index=models.CharField(max_length=20)
    location=models.CharField(max_length=30)
    t=models.CharField(max_length=20)
    recommnend_mark=models.CharField(max_length=30)
    h_type=models.ManyToManyField(Hotel_type)
    def __unicode__(self):
        return self.hname
class Hot_yl(models.Model):
    area=models.ForeignKey(Area)
    name=models.CharField(max_length=30)
    index=models.CharField(max_length=20)
    def __unicode(self):
        return self.name
 class Youji(models.Model):
    area=models.ManyToManyField(Area)
    author=models.CharField(max_length=50)
    title=models.CharField(max_length=50)
    desc=models.CharField(max_length=50)
    look=models.IntegerField()
    keys=models.CharField(max_length=50)
    comment=models.IntegerField()
    img=models.ImageField(upload_to='images/pic')
    content=models.TextField()
    pubtime=models.DateTimeField()
    travel_type=models.CharField(max_length=50)
    use_time=models.IntegerField()
    money=money.IntegerField()
    score=models.CharField(max_length=50)
    class Meta:
        ordering=['-score','-pubtime']
    def __unicode__(self):
        return self.title
class Dianping(models.Model):
    area=models.ForeignKey(Area)
    author=models.CharField(max_length=50)
    content=models.TextField()
    time=models.DateTimeField()
    score=models.CharField(max_length=100)
    class Meta:
        ordering=['score','time']
    def __unicode__(self):
        return self.id

class Question(models.Model):
    area=models.ManyToManyField(Area)
    title=models.CharField(max_length=50)
    content=models.TextField()
    time=models.DateTimeField()
    score=models.CharField(max_length=50)
    answer=models.CharField(max_length=100)
    class Meta:
        ordering=['score','id']
    def __unicode__(self):
        return self.title      
class root(models.Model):
    area=models.ForeignKey(Area)
    use_time=models.CharField(max_length=20)
    title=models.CharField(max_length=30)
    desc=models.CharField(max_length=100)
    info=models.CharField(max_length=50)
    img=models.ImageField(upload_to='images/pic')
    use_money=models.CharField(max_length=20)
    index=models.CharField(max_length=30)
    def __unicode__(self):
        return self.titled
# 
class Hot_search(models.Model):
    area=models.ForeignKey(Area)
    # 1 you 2 chi 3 zhu 4 youji 5 q
    Type=models.IntegerField()
    search=models.CharField(max_length=20)
















