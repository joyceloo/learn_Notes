from django.shortcuts import render,HttpResponse
from models import *
import json

# Create your views here

def get_area_data(request,aid):
    area_id=aid
    try:
        area=Area.objects.filter(a_id=area_id)
        charm_value=Charm_value.objects.filter(area=area)
        hot_areas=Hot_areas.objects.filter(area=area)[:6]
        roots=root.objects.filter(area=area)[:3]
        spots=Hot_spot.objects.filter(area=area)[:6]
        foods=Hot_food.objects.filter(area=area)[:6]
        hotels=Hot_hotel.objects.filter(area=area)[:6]
        leisures=Hot_yl.objects.filter(area=area)[:20]
        youji_lists=Youji.objects.filter(area=area)[:4]
        dp_lists=Dianping.objects.filter(area=area)[:5]
        Q_lists=Question.objects.filter(area=area)[:5]
        s_search=Hot_search.objects.filter(area=area,Type=1)[:15]
        f_search=Hot_search.objects.filter(area=area,Type=1)[:15]
        h_search=Hot_search.objects.filter(area=area,Type=1)[:15]
        youji_search=Hot_search.objects.filter(area=area,Type=1)[:15]
        q_search=Hot_search.objects.filter(area=area,Type=1)[:15]
        return render(request,'pro_common.html',locals())




		
