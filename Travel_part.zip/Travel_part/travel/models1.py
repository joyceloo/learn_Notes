# -*- coding: utf-8 -*-
#分开 spot hotel resta
from __future__ import unicode_literals

from django.db import models

# 地区基本信息表
class Area(models.Model):
    # 1sheng 2shi 3xian 4zhen 5cun
    Type=models.IntegerField()
    aname=models.CharField(max_length=50)
    a_id=models.CharField(max_length=100)
    apinyin=models.CharField(max_length=50)
    alongitude=models.FloatField()
    alatitude=models.FloatField()
    adesc=models.TextField()
    aparent=models.CharField(max_length=50)
    aimg=models.ImageField(upload_to="images/pic")
    arank=models.CharField(max_length=100)
    class Meta:
        ordering=['arank']
    def __unicode__(self):
        return self.aname
class Charm_value(models.Model):
    area=models.OneToOneField(Area)
    mark=models.CharField(max_length=30)
    renqi=models.CharField(max_length=30)
    fuwu=models.CharField(max_length=30)
    manyidu=models.CharField(max_length=30)
    def __unicode__(self):
        return self.area

# 1景区 2酒店 3餐厅 基本信息
class BaseInfo(models.Model):
    name=models.CharField(max_length=50)
    longitude=models.FloatField()
    latitude=models.FloatField()
    Type=models.IntegerField()
    img=models.ImageField(upload_to='images/pic')
    score=models.CharField(max_length=100)
    class Meta:
        abstract=True
class Spot(BaseInfo):
    area=models.ForeignKey(Area)
    def __unicode__(self):
        return self.name
class Hotel(BaseInfo):
    area=models.ForeignKey(Area)
    def __unicode__(self):
        return self.name
class Restaurant(BaseInfo):
    area=models.ForeignKey(Area)
    def __unicode__(self):
        return self.name
class Youji(models.Model):
    area=models.ManyToManyField(Area)
    spot=models.ManyToManyField(Spot)
    hotel=models.ManyToManyField(Hotel)
    restaurant=models.ManyToManyField(Restaurant)
    author=models.CharField(max_length=50)
    title=models.CharField(max_length=50)
    desc=models.CharField(max_length=50)
    img=models.ImageField(upload_to='images/pic')
    content=models.TextField()
    pubtime=models.DateTimeField()
    travel_type=models.CharField(max_length=50)
    score=models.CharField(max_length=50)
    class Meta:
        ordering=['score','pubtime']
    def __unicode__(self):
        return self.title
class Youji_comment(models.Model):
    youji=models.ForeignKey(Youji)
    content=models.TextField()
    comment_time=models.DateTimeField()
    comment_author=models.CharField(max_length=50)
    def __unicode__(self):
        return self.youji
